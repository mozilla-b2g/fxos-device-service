
define([],function(){'use strict';return navigator.battery;});